To run the program (when the requirements in requirements.txt are installed), run the file runme.ipynb
Every part is commented with which question it works on
Q10 and Q11 share one code for prediction. To predict Q10, first run Q10 and then the #prediction for fencing code at the end.
For Q11, first run Q11 and then the same #prediction for fencing- code