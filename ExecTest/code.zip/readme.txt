
To run the program (when the requirements in requirements.txt are installed), write:

python runme.py

The program will go through the listed Q python files in sequence, and wait for user input before each new file is loaded